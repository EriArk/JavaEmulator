AbyssME 0.8.0 Beta 1 — Social Media Review Pack
Draft media selection • 2026-11-22

CURRENT PUBLIC RELEASE: 0.8.0 Beta 1 — 24 platforms on ARM64, Java ME / Mophun only on ARMv7.
DEVELOPMENT WORK: 32 platforms integrated privately, 8 withheld from release pending redistribution permission.
LONG-TERM GOAL: 70 platform shelves.

RECOMMENDED ORDER
01 • Platform gallery — first/hero image. IMPORTANT: screenshot from a private development build and includes some devices NOT in public Beta 1.
02 • ESPboy game shelf — communicates the real game library; private development build.
03 • ESPboy Cityrunner — game running with touch controls and retained high score; private development build.
04 • Original Thumby / Alien Invasion — another, visually distinct playable platform; private development build.
05 • ESPboy physical button mapper — shows shared control system; private development build.

VIDEOS
01 • Gallery focus — short real Retroid platform selection recording from private development build.
02 • Right-stick and Asphalt gameplay — 23 seconds, older PUBLIC SIGNED 0.7.0 Beta 9, silent. Do not label it as Beta 1.

SUGGESTED REDDIT
Use 01 as cover, followed by 02 / 03 / 04 / 05 (optional). Keep at most one video in a video-first variant.
Caption: "The current release includes 24 platforms; some images show the larger private development build."

SUGGESTED DISCORD
Attach 01 + 03 + 04, and video 01 as a separate message. Video 02 is an older controls-demo supplement.

This pack contains real captured UI or gameplay from the project repository.
No fake mockups. No APKs, ROMs, BIOS or firmware. The historical info-card UI is planned, not yet released.
Some controller events in the documented captures were injected; see original source notes.

Source: https://github.com/EriArk/JavaEmulator
Release: https://github.com/EriArk/JavaEmulator/releases/tag/v0.8.0-beta.1
